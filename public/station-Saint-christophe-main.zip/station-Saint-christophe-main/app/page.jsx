"use client";

import Image from "next/image";
import { useMemo, useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  FaEuroSign,
  FaFilter,
  FaMapMarkerAlt,
  FaSearch,
  FaTag,
  FaTools,
} from "react-icons/fa";
import { FaGaugeHigh } from "react-icons/fa6";

const inventory = [
  {
    id: 1,
    name: "Bloc moteur Renault Clio IV 1.5 dCi",
    price: 1480,
    category: "Pièces détachées",
    type: "Moteur",
    compatibility: "Compatibilité 2018-2023",
    description:
      "Bloc moteur révisé avec turbo inclus, livré avec garantie 12 mois.",
    location: "Atelier Lyon",
    mileage: "42 000 km",
    stock: 3,
    image:
      "https://images.unsplash.com/photo-1517153295259-74e4e5a6c9a8?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: 2,
    name: "Capot avant Peugeot 208 GT Line",
    price: 420,
    category: "Pièces détachées",
    type: "Carrosserie",
    compatibility: "Compatibilité 2020-2024",
    description:
      "Capot d'origine peint noir obsidienne avec insonorisation thermique.",
    location: "Dépôt Grenoble",
    mileage: null,
    stock: 6,
    image:
      "https://images.unsplash.com/photo-1494905998402-395d579af36f?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: 3,
    name: "Renault Zoe Life 40 kWh",
    price: 11990,
    category: "Véhicules d'occasion",
    type: "Électricité",
    compatibility: "Mise en circulation 2021",
    description:
      "Compacte électrique 22 800 km, entretien suivi chez Renault, batterie louée.",
    location: "Parc véhicules Chambéry",
    mileage: "22 800 km",
    stock: 1,
    image:
      "https://images.unsplash.com/photo-1610394146075-5a97d5f43bf5?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: 4,
    name: "Boîte de vitesse BVM6 BMW Série 3",
    price: 960,
    category: "Pièces détachées",
    type: "Transmission",
    compatibility: "Diesel B47 2016-2022",
    description:
      "Boîte manuelle 6 rapports reconditionnée, contrôlée sur banc avant expédition.",
    location: "Atelier Valence",
    mileage: "58 000 km",
    stock: 2,
    image:
      "https://images.unsplash.com/photo-1523983388277-336a66bf9bcd?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: 5,
    name: "Intérieur cuir Alfa Romeo Giulia",
    price: 1680,
    category: "Accessoires",
    type: "Intérieur",
    compatibility: "Sellerie complète 2017-2022",
    description:
      "Sellerie cuir rouge et noir, sièges chauffants avec commandes électriques.",
    location: "Showroom Annecy",
    mileage: null,
    stock: 1,
    image:
      "https://images.unsplash.com/photo-1571973084359-840a1fda16f0?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: 6,
    name: "Kit freinage performance Audi S3",
    price: 780,
    category: "Pièces détachées",
    type: "Freinage",
    compatibility: "Disques percés + plaquettes",
    description:
      "Kit avant complet avec étriers 4 pistons, purge faite et garantie 6 mois.",
    location: "Atelier Annecy",
    mileage: null,
    stock: 4,
    image:
      "https://images.unsplash.com/photo-1503736334956-4c8f8e92946d?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: 7,
    name: "Pare-chocs arrière Citroën C5 Aircross",
    price: 360,
    category: "Pièces détachées",
    type: "Carrosserie",
    compatibility: "Version Shine 2019-2024",
    description:
      "Pare-chocs arrière avec capteurs de recul calibrés et peinture gris platinium.",
    location: "Dépôt Grenoble",
    mileage: null,
    stock: 5,
    image:
      "https://images.unsplash.com/photo-1617581624498-5c0ae9fc0f59?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: 8,
    name: "Moteur hybride Toyota Yaris",
    price: 2440,
    category: "Pièces détachées",
    type: "Moteur",
    compatibility: "1.5 Hybrid Dynamic Force",
    description:
      "Bloc hybride complet livré avec batterie HV testée et garantie 18 mois.",
    location: "Atelier Lyon",
    mileage: "35 500 km",
    stock: 2,
    image:
      "https://images.unsplash.com/photo-1581579186983-7d0835f7018f?q=80&w=1200&auto=format&fit=crop",
  },
];

const categories = ["Toutes les catégories", ...new Set(inventory.map((item) => item.category))];
const typeFilters = Array.from(new Set(inventory.map((item) => item.type)));
const maxPrice = Math.max(...inventory.map((item) => item.price));

export default function Home() {
  const [searchTerm, setSearchTerm] = useState("");
  const [priceThreshold, setPriceThreshold] = useState(maxPrice);
  const [category, setCategory] = useState("Toutes les catégories");
  const [activeTypes, setActiveTypes] = useState(typeFilters);
  const [sortOption, setSortOption] = useState("recent");

  const filteredInventory = useMemo(() => {
    const activeTypeList = activeTypes.length ? activeTypes : typeFilters;

    const filtered = inventory.filter((item) => {
      const matchesSearch = item.name
        .toLowerCase()
        .includes(searchTerm.trim().toLowerCase());
      const matchesCategory =
        category === "Toutes les catégories" || item.category === category;
      const matchesPrice = item.price <= priceThreshold;
      const matchesType = activeTypeList.includes(item.type);

      return matchesSearch && matchesCategory && matchesPrice && matchesType;
    });

    const sorted = [...filtered].sort((a, b) => {
      switch (sortOption) {
        case "price-asc":
          return a.price - b.price;
        case "price-desc":
          return b.price - a.price;
        case "name":
          return a.name.localeCompare(b.name, "fr");
        default:
          return b.id - a.id;
      }
    });

    return sorted;
  }, [searchTerm, category, priceThreshold, activeTypes, sortOption]);

  const toggleType = (type) => {
    setActiveTypes((current) =>
      current.includes(type)
        ? current.filter((item) => item !== type)
        : [...current, type],
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 via-slate-50 to-white">
      <div className="mx-auto flex w-full max-w-7xl flex-col gap-10 px-6 py-12 lg:flex-row">
        <aside className="w-full shrink-0 lg:max-w-xs">
          <Card className="sticky top-8 border-none bg-white/80 backdrop-blur">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-xl font-semibold text-slate-900">
                    Filtres intelligents
                  </CardTitle>
                  <CardDescription className="mt-1 text-sm text-slate-500">
                    Affinez les résultats selon vos besoins.
                  </CardDescription>
                </div>
                <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600">
                  <FaFilter className="text-lg" />
                </span>
              </div>
            </CardHeader>
            <CardContent className="flex flex-col gap-6">
              <div className="flex flex-col gap-2">
                <Label htmlFor="search" className="flex items-center gap-2 text-xs uppercase tracking-widest text-slate-500">
                  <FaSearch className="text-slate-400" /> Recherche
                </Label>
                <Input
                  id="search"
                  placeholder="Rechercher une pièce ou un véhicule"
                  value={searchTerm}
                  onChange={(event) => setSearchTerm(event.target.value)}
                />
              </div>

              <Separator />

              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <Label
                    htmlFor="price"
                    className="flex items-center gap-2 text-xs uppercase tracking-widest text-slate-500"
                  >
                    <FaEuroSign className="text-slate-400" /> Budget max
                  </Label>
                  <span className="text-sm font-semibold text-slate-700">
                    {new Intl.NumberFormat("fr-FR", {
                      style: "currency",
                      currency: "EUR",
                      maximumFractionDigits: 0,
                    }).format(priceThreshold)}
                  </span>
                </div>
                <input
                  id="price"
                  type="range"
                  min={Math.min(...inventory.map((item) => item.price))}
                  max={maxPrice}
                  value={priceThreshold}
                  onChange={(event) => setPriceThreshold(Number(event.target.value))}
                  className="h-2 w-full cursor-pointer appearance-none rounded-full bg-slate-200 accent-indigo-600"
                />
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>
                    {new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0 }).format(
                      Math.min(...inventory.map((item) => item.price)),
                    )}
                    €
                  </span>
                  <span>{new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0 }).format(maxPrice)}€</span>
                </div>
              </div>

              <Separator />

              <div className="flex flex-col gap-2">
                <Label htmlFor="category" className="flex items-center gap-2 text-xs uppercase tracking-widest text-slate-500">
                  <FaTag className="text-slate-400" /> Catégorie
                </Label>
                <Select
                  id="category"
                  value={category}
                  onChange={(event) => setCategory(event.target.value)}
                >
                  {categories.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </Select>
              </div>

              <Separator />

              <div className="flex flex-col gap-3">
                <p className="flex items-center gap-2 text-xs uppercase tracking-widest text-slate-500">
                  <FaTools className="text-slate-400" /> Types de pièces
                </p>
                <div className="grid grid-cols-1 gap-3">
                  {typeFilters.map((type) => {
                    const checked = activeTypes.includes(type);
                    return (
                      <label
                        key={type}
                        className={`flex cursor-pointer items-center justify-between rounded-xl border px-3 py-3 transition ${
                          checked ? "border-indigo-200 bg-indigo-50" : "border-slate-200 hover:border-indigo-200"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <Checkbox
                            checked={checked}
                            onChange={() => toggleType(type)}
                            className="h-4 w-4"
                          />
                          <span className="text-sm font-medium text-slate-700">{type}</span>
                        </div>
                        <Badge variant={checked ? "default" : "outline"}>
                          {inventory.filter((item) => item.type === type).length}
                        </Badge>
                      </label>
                    );
                  })}
                </div>
              </div>

              <Separator />

              <div className="flex flex-col gap-2">
                <Label htmlFor="sort" className="flex items-center gap-2 text-xs uppercase tracking-widest text-slate-500">
                  <FaGaugeHigh className="text-slate-400" /> Trier par
                </Label>
                <Select
                  id="sort"
                  value={sortOption}
                  onChange={(event) => setSortOption(event.target.value)}
                >
                  <option value="recent">Plus récent</option>
                  <option value="price-asc">Prix croissant</option>
                  <option value="price-desc">Prix décroissant</option>
                  <option value="name">Ordre alphabétique</option>
                </Select>
              </div>
            </CardContent>
          </Card>
        </aside>

        <section className="flex-1">
          <div className="flex flex-col gap-6">
            <div className="flex flex-col gap-4 rounded-3xl border border-slate-200 bg-white/80 p-6 backdrop-blur lg:flex-row lg:items-center lg:justify-between">
              <div>
                <h1 className="text-2xl font-semibold text-slate-900 md:text-3xl">
                  Sélection de la station Saint Christophe
                </h1>
                <p className="mt-2 max-w-2xl text-sm text-slate-500">
                  Visualisez en un coup d'œil l'ensemble des pièces, véhicules et accessoires disponibles. Utilisez la barre
                  latérale pour filtrer selon votre budget, une catégorie précise ou un type de pièce.
                </p>
              </div>
              <div className="flex items-center gap-3 rounded-2xl bg-indigo-50 px-5 py-3 text-indigo-700">
                <span className="text-sm font-medium">Résultats trouvés</span>
                <span className="text-2xl font-semibold">{filteredInventory.length}</span>
              </div>
            </div>

            <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
              {filteredInventory.map((item) => (
                <Card key={item.id} className="overflow-hidden border-none bg-white/90">
                  <div className="relative h-48 w-full overflow-hidden">
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      unoptimized
                      className="h-full w-full object-cover transition-transform duration-500 hover:scale-105"
                      sizes="(min-width: 1280px) 360px, (min-width: 768px) 50vw, 100vw"
                    />
                    <div className="absolute inset-x-4 top-4 flex items-center gap-2">
                      <Badge className="bg-white/90 text-slate-700">{item.category}</Badge>
                      <Badge variant="soft">{item.type}</Badge>
                    </div>
                  </div>
                  <CardHeader className="pb-4">
                    <CardTitle className="text-xl text-slate-900">{item.name}</CardTitle>
                    <CardDescription>{item.compatibility}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex flex-col gap-4">
                    <p className="text-sm leading-6 text-slate-600">{item.description}</p>
                    <div className="flex flex-wrap items-center gap-3 text-sm text-slate-500">
                      {item.location && (
                        <span className="inline-flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1">
                          <FaMapMarkerAlt className="text-slate-400" /> {item.location}
                        </span>
                      )}
                      {item.mileage && (
                        <span className="inline-flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1">
                          <FaGaugeHigh className="text-slate-400" /> {item.mileage}
                        </span>
                      )}
                      <span className="inline-flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1">
                        <FaTools className="text-slate-400" /> Stock : {item.stock}
                      </span>
                    </div>
                  </CardContent>
                  <CardFooter className="items-end">
                    <div className="flex flex-col">
                      <span className="text-xs uppercase tracking-widest text-slate-400">
                        Tarif TTC
                      </span>
                      <span className="text-2xl font-semibold text-slate-900">
                        {new Intl.NumberFormat("fr-FR", {
                          style: "currency",
                          currency: "EUR",
                          maximumFractionDigits: 0,
                        }).format(item.price)}
                      </span>
                    </div>
                    <button
                      type="button"
                      className="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                    >
                      <FaEuroSign /> Demander un devis
                    </button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
