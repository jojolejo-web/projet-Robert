import * as React from "react";
import { cn } from "@/lib/utils";

const Badge = React.forwardRef(function Badge(
  { className, variant = "default", ...props },
  ref,
) {
  return (
    <span
      ref={ref}
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-wide",
        variant === "default" && "border-transparent bg-indigo-100 text-indigo-700",
        variant === "outline" && "border-slate-200 bg-white text-slate-600",
        variant === "soft" && "border-transparent bg-slate-100 text-slate-600",
        className,
      )}
      {...props}
    />
  );
});

export { Badge };
